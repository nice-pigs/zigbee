#include "wifi.h"
#include <string.h>
#include "hal_lcd.h"
#include "uart.h"
#include "bluetooth.h"
extern void DelayMS(unsigned int msec);  // �ⲿ��ʱ����

// ȫ�ֱ���
int g_timeout = 0;
int g_thread = 0;


/****************************************************************
WIFIģ��ĸ�λ			
****************************************************************/
void Wifi_info(void)
{
  clearBuffU1();
  Uart1_Send_String(RST_C);
  DelayMS(2000);
  LCD_P8x16Str(8,2,"Wifi infor....");
  if(strstr((char const *)RecdataU1,"OK")==NULL)
  {
    LCD_P8x16Str(8,2,"Wifi infor....");
    DelayMS(3000);
  }
  else
  {
    LCD_P8x16Str(8,2,"Wifi infor[OK]");
    DelayMS(500);
  }
   Uart0_Send_String(RecdataU1);
   Uart0_Send_String("\r\n");
}

/****************************************************************
WIFIģ���ZigBee���ӣ� ���ӵ�ʱ��D1����˸
****************************************************************/
void Connect_Wifi(void)
{
  
  clearBuffU1();
  Uart1_Send_String(AT_C);
  LCD_P8x16Str(8,2,"connect......."); 

  while(strstr((char const *)RecdataU1,"OK")==NULL)
  {
    LCD_P8x16Str(8,2,"connect.......");
    DelayMS(5000);
    LED1=1;
    DelayMS(500);
    LED1=0;
  }
  Uart0_Send_String(RecdataU1);
  Uart0_Send_String("\r\n");
  LCD_P8x16Str(8,2,"connect...[OK]");
  DelayMS(2000);
  LED1=0;
}

/****************************************************************
��ʼ��ģ�鵥ͨ��������D2����˸
****************************************************************/

void Init_MUX(void)
{ 
  clearBuffU1();
  Uart1_Send_String(MUX_C);
  
  while(strstr((char const *)RecdataU1,"OK")==NULL)
  {
    LCD_P8x16Str(8,2,"Init MUX......");
    DelayMS(3000);
    LED2=1;
    DelayMS(500);
    LED2=0;
  }
  Uart0_Send_String(RecdataU1);
  Uart0_Send_String("\r\n");
  LCD_P8x16Str(8,2,"Init MUX..[OK]");
  LED2=0;
}


/****************************************************************
��ʼ��ģ��ɷ�����������D3����˸
****************************************************************/
void Init_Server(void)
{
  
  
  clearBuffU1();
  Uart1_Send_String(SERVER_C);
  DelayMS(500);
  
  while(strstr((char const *)RecdataU1,"OK")==NULL)
  {
    LCD_P8x16Str(8,2,"Init Server...");
    DelayMS(3000);
    LED3=1;
    DelayMS(2000);
    LED3=0;
  }
  Uart0_Send_String(RecdataU1);
  Uart0_Send_String("\r\n");
  LCD_P8x16Str(8,2,"TCP Server[OK]");
  LED3=0;
}

/**
 * �������ݵ�WiFiģ��
 */
int Send_Wifi_DATA(char *str, int len)
{
    char SEND_C[20];
    memset(SEND_C, 0, 20);
    sprintf(SEND_C, "AT+CIPSEND=%d,%d\r\n", g_thread, len);

    Uart1_Send_String(SEND_C);
    DelayMS(200);

    while (strstr((char const *)RecdataU1, ">") == NULL)
    {
        if (g_timeout > 50)
        {
            g_timeout = 0;
            return -1;
        }
        DelayMS(5);
        g_timeout++;
    }
    Uart1_Send_String(str);
    return 0;
}

/**
 * ����WiFi���ݿ��Ƶ�״̬
 */
void Wifi_Ctrl_ZGBLED(const char *str)
{
  
    if (strstr(str, "ESPGLED1") != NULL)
    {
        LED1 = 1;
    }
    if (strstr(str, "ESPKLED1") != NULL)
    {
        LED1 = 0;
    }

    if (strstr(str, "ESPGLED2") != NULL)
    {
        LED2 = 1;
    }
    if (strstr(str, "ESPKLED2") != NULL)
    {
        LED2 = 0;
    }

    if (strstr(str, "ESPGLED3") != NULL)
    {
        LED3 = 1;
    }
    if (strstr(str, "ESPKLED3") != NULL)
    {
        LED3 = 0;
    }
}
