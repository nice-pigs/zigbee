#ifndef UART_H
#define UART_H

#include <iocc2530.h>
#include <stdio.h>
#include <string.h>

// ���Ͷ���
typedef unsigned char uchar;
typedef unsigned int  uint;

// �궨��
#define MAXCHAR 81

// ����״̬
extern uint lenU0;
extern uchar tempRXU0;
extern uchar RecdataU0[MAXCHAR];

extern uint lenU1;
extern uchar tempRXU1;
extern uchar RecdataU1[MAXCHAR];

// ��������
void initUART0(void);
void initUART1(void);
void Uart0_Send_Char(uchar ch);
void Uart0_Send_String(uchar *str);
void Uart1_Send_Char(uchar Data);
void Uart1_Send_String(uchar *Data);
void clearBuffU0(void);
void clearBuffU1(void);
uint UART0_GetData(uchar *buffer, uint maxLen);
uint UART1_GetData(uchar *buffer, uint maxLen);

// �ⲿ����
extern void DelayMS(unsigned int msec);

#endif // UART_H
