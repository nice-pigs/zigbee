#ifndef WIFI_H
#define WIFI_H

#include <iocc2530.h>

//������ƵƵĶ˿�
#define LED1 P1_0
#define LED2 P1_1
#define LED3 P1_6

// WiFi����
#define AT_C     "AT\r\n"
#define MUX_C    "AT+CIPMUX=1\r\n"
#define SERVER_C "AT+CIPSERVER=1,5000\r\n"
#define RST_C    "AT+CIFSR\r\n"

// �����жϹؼ���
#define Rev_F    "+IPD"
#define Rev_TUL  "link is not valid"
#define Rev_TLI  "CONNECT"
#define Rev_GD   "GETDATA"
#define Rev_TUL1 "CONNECT FAIL"
#define Rev_FAIL "FAIL"

// ��ʼ��WiFiģ��
void Wifi_info(void);
void Connect_Wifi(void);
void Init_MUX(void);
void Init_Server(void);

// WiFi���ݷ���
int Send_Wifi_DATA(char *str, int len);

// WiFi�ƿ���
void Wifi_Ctrl_ZGBLED(const char *str);



#endif // WIFI_H
